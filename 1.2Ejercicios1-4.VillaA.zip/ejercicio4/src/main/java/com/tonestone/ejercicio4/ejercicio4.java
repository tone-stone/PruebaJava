
package com.tonestone.ejercicio4;

import java.util.Scanner;

public class ejercicio4 {

   
    public static void main(String[] args) {
        
        int num1; int num2; int num3;
           
       Scanner entrada = new Scanner(System.in);
        
        System.out.println("Dame un numero");
        num1 = entrada.nextInt();
        System.out.println("Ingresa el segundo valor");
        num2 = entrada.nextInt(); 
        System.out.println("Ingresa el tercer valor");
        num3 = entrada.nextInt();
       
       if (num1 == num2)
       {
           System.out.println("Los valores son iguales");
       } else {
       }
          
    }
    
}

