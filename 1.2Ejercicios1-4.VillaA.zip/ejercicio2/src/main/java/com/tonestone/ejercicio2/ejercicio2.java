
package com.tonestone.ejercicio2;

import java.util.Scanner;
        
public class ejercicio2 {

   
    public static void main(String[] args) {
       
        int numero;
        int resultado;
        
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Dame un numero");
        numero = entrada.nextInt();
                // necesito ver si es par o impar
                resultado = numero%2;
                
                if (resultado == 0){ 
                    System.out.println("Ese numero es par");                    
             }else{
                    System.out.println("El numero es impar");               
                }
        
    }
    
}
