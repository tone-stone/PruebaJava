
package com.tonestone.ejercicio3;

import java.util.Scanner;
public class ejercicio3 {

  
    public static void main(String[] args) {
        
       int num1; int num2;
           
       Scanner entrada = new Scanner(System.in);
        
        System.out.println("Ingresa el primer valor");
        num1 = entrada.nextInt();
       System.out.println("Ingresa el segundo valor");
       num2 = entrada.nextInt(); 
       
       if(num1 == num2)
       {
            System.out.println("Los valores son iguales");
       }
    
       else if (num1 > num2){
       System.out.println("El Primer Valor  es Mayor ");
       }
       else {
    System.out.println("El Segundo Valor  es Mayor");
 
      }
       
    }
    
}
