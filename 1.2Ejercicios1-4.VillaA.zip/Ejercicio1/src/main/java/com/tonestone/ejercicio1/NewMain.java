
package com.tonestone.ejercicio1;

import java.util.Scanner;

public class NewMain {

  
    public static void main(String[] args) {
        
        int cal1;
        int cal2;
        int cal3;
        int cal4;
        double calfinal;
        
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Dame la primera calificacion Cal1:");
        cal1 = entrada.nextInt();
       System.out.println("Dame la segunda calificacion Cal2");
        cal2 = entrada.nextInt();
        System.out.println("Dame la tercera calificacion Cal3");
        cal3 = entrada.nextInt();
        System.out.println("Dame la cuarta calificacion Cal4");
        cal4 = entrada.nextInt();
        calfinal = (cal1+cal2+cal3+cal4)/4;
        
        System.out.println("Tu promedio es: "+calfinal);
        
    }
    
}
